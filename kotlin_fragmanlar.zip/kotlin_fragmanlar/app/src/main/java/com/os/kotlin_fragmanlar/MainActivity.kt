
package com.os.kotlin_fragmanlar

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    fun onceki(view: View){
        val fragmentManager=supportFragmentManager
        val fragmentTransaction=fragmentManager.beginTransaction()
        val ilkfragman=BlankFragment()
        fragmentTransaction.replace(R.id.frameLayout1,ilkfragman).commit()
    }

    fun sonraki(view: View){
        val fragmentManager=supportFragmentManager
        val fragmentTransaction=fragmentManager.beginTransaction()
        val ikincifragman=BlankFragment2()
        fragmentTransaction.replace(R.id.frameLayout1,ikincifragman).commit()
    }
}